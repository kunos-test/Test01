package com.example.postit

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/**
 * 홈화면을 포함한 다른 화면 위에 메모지를 띄우고,
 * 손가락 드래그로 자유롭게 옮길 수 있게 한다.
 */
class FloatingNoteService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.postit.action.SHOW"
        const val ACTION_CLOSE_ALL = "com.example.postit.action.CLOSE_ALL"
        const val ACTION_SET_OPACITY = "com.example.postit.action.SET_OPACITY"

        const val EXTRA_ID = "extra_id"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_COLOR = "extra_color"
        const val EXTRA_OPACITY = "extra_opacity"

        private const val CHANNEL_ID = "postit_overlay"
        private const val NOTIFICATION_ID = 7001
    }

    private lateinit var windowManager: WindowManager
    private val views = HashMap<String, View>()
    private val layoutParams = HashMap<String, WindowManager.LayoutParams>()
    private var notes = mutableListOf<Note>()
    private var touchSlop = 8
    private var baseAlpha = 1f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        goForeground()

        // 재부팅이나 강제종료 이후에도 마지막 상태를 복원한다.
        baseAlpha = NoteStore.loadOpacity(this) / 100f
        notes = NoteStore.load(this)
        notes.forEach { attach(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SET_OPACITY -> {
                val percent = intent.getIntExtra(EXTRA_OPACITY, 100)
                baseAlpha = percent.coerceIn(20, 100) / 100f
                views.values.forEach { it.alpha = baseAlpha }
                return START_STICKY
            }
            ACTION_CLOSE_ALL -> {
                closeAll()
                return START_NOT_STICKY
            }
            ACTION_SHOW -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: System.currentTimeMillis().toString()
                val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
                val color = intent.getIntExtra(EXTRA_COLOR, 0xFFFFE08A.toInt())

                val existing = notes.firstOrNull { it.id == id }
                if (existing == null) {
                    val note = Note(id = id, text = text, color = color, y = 240 + notes.size * 60)
                    notes.add(note)
                    attach(note)
                } else {
                    existing.text = text
                    existing.color = color
                    refresh(existing)
                }
                NoteStore.save(this, notes)
            }
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------- 메모지 부착

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun attach(note: Note) {
        if (views.containsKey(note.id)) {
            refresh(note)
            return
        }

        val view = LayoutInflater.from(this).inflate(R.layout.view_floating_note, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = note.x
            y = note.y
        }

        // 닫기 버튼은 자식 뷰라 부모의 터치 리스너보다 먼저 이벤트를 받는다.
        view.findViewById<View>(R.id.closeButton).setOnClickListener { remove(note) }

        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    dragging = false
                    v.alpha = baseAlpha * 0.9f
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) dragging = true
                    if (dragging) {
                        params.x = startX + dx
                        params.y = startY + dy
                        runCatching { windowManager.updateViewLayout(v, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = baseAlpha
                    if (dragging) {
                        clampIntoScreen(params, v)
                        runCatching { windowManager.updateViewLayout(v, params) }
                        note.x = params.x
                        note.y = params.y
                        NoteStore.save(this, notes)
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        openEditor(note)
                    }
                    true
                }

                else -> false
            }
        }

        view.alpha = baseAlpha
        runCatching { windowManager.addView(view, params) }
        views[note.id] = view
        layoutParams[note.id] = params
        refresh(note)
    }

    private fun refresh(note: Note) {
        val view = views[note.id] ?: return
        view.findViewById<TextView>(R.id.noteText).text = note.text
        val paper = view.findViewById<View>(R.id.paper)
        (paper.background.mutate() as? GradientDrawable)?.setColor(note.color)
    }

    /** 메모지가 화면 밖으로 완전히 나가 다시 잡을 수 없게 되는 것을 막는다. */
    private fun clampIntoScreen(params: WindowManager.LayoutParams, view: View) {
        val metrics = resources.displayMetrics
        val minVisible = (48 * metrics.density).toInt()
        val maxX = metrics.widthPixels - minVisible
        val maxY = metrics.heightPixels - minVisible
        params.x = params.x.coerceIn(minVisible - view.width, maxX)
        params.y = params.y.coerceIn(0, maxY)
    }

    // ---------------------------------------------------------------- 제거

    private fun remove(note: Note) {
        views.remove(note.id)?.let { runCatching { windowManager.removeView(it) } }
        layoutParams.remove(note.id)
        notes.removeAll { it.id == note.id }
        NoteStore.save(this, notes)
        if (notes.isEmpty()) stopSelf()
    }

    private fun closeAll() {
        views.values.forEach { runCatching { windowManager.removeView(it) } }
        views.clear()
        layoutParams.clear()
        notes.clear()
        NoteStore.save(this, notes)
        stopSelf()
    }

    override fun onDestroy() {
        views.values.forEach { runCatching { windowManager.removeView(it) } }
        views.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 편집 / 알림

    private fun openEditor(note: Note) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_ID, note.id)
            putExtra(EXTRA_TEXT, note.text)
            putExtra(EXTRA_COLOR, note.color)
        }
        startActivity(intent)
    }

    private fun goForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }

        val closeAll = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingNoteService::class.java).setAction(ACTION_CLOSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(R.string.close_all), closeAll)
            .build()

        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
    }
}
