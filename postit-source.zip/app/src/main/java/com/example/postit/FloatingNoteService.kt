package com.example.postit

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/**
 * 홈화면을 포함한 다른 화면 위에 메모지를 띄우고,
 * 손가락 드래그로 자유롭게 옮길 수 있게 한다.
 */
class FloatingNoteService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.postit.action.SHOW"
        const val ACTION_CLOSE_ALL = "com.example.postit.action.CLOSE_ALL"
        const val ACTION_SET_OPACITY = "com.example.postit.action.SET_OPACITY"
        const val ACTION_TOGGLE_HIDE = "com.example.postit.action.TOGGLE_HIDE"

        const val EXTRA_ID = "extra_id"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_COLOR = "extra_color"
        const val EXTRA_TEXT_COLOR = "extra_text_color"
        const val EXTRA_SHAPE = "extra_shape"
        const val EXTRA_OPACITY = "extra_opacity"

        private const val CHANNEL_ID = "postit_overlay"
        private const val NOTIFICATION_ID = 7001
        private const val MIN_SCALE = 0.5f
        private const val MAX_SCALE = 1.5f
    }

    private lateinit var windowManager: WindowManager
    private val views = HashMap<String, View>()
    private val layoutParams = HashMap<String, WindowManager.LayoutParams>()
    private var notes = mutableListOf<Note>()
    private var touchSlop = 8
    private var baseAlpha = 1f
    /** 잠시 접어둔 상태. 메모는 지워지지 않고 화면에서만 사라진다. */
    private var hidden = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        goForeground()

        // 재부팅이나 강제종료 이후에도 마지막 상태를 복원한다.
        baseAlpha = NoteStore.loadOpacity(this) / 100f
        notes = NoteStore.load(this)
        notes.forEach { attach(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE_HIDE -> {
                if (hidden) showAll() else hideAll()
                return START_STICKY
            }
            ACTION_SET_OPACITY -> {
                val percent = intent.getIntExtra(EXTRA_OPACITY, 100)
                baseAlpha = percent.coerceIn(20, 100) / 100f
                views.values.forEach { it.alpha = baseAlpha }
                return START_STICKY
            }
            ACTION_CLOSE_ALL -> {
                closeAll()
                return START_NOT_STICKY
            }
            ACTION_SHOW -> {
                // 접어둔 채로 새 메모를 붙이면 아무것도 안 보이므로 먼저 펼친다
                if (hidden) showAll()
                val id = intent.getStringExtra(EXTRA_ID) ?: System.currentTimeMillis().toString()
                val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
                val color = intent.getIntExtra(EXTRA_COLOR, Note.DEFAULT_PAPER)
                val textColor = intent.getIntExtra(EXTRA_TEXT_COLOR, Note.DEFAULT_TEXT)
                val shape = intent.getStringExtra(EXTRA_SHAPE) ?: Note.SHAPE_PAPER

                val existing = notes.firstOrNull { it.id == id }
                if (existing == null) {
                    val note = Note(
                        id = id, text = text, color = color,
                        textColor = textColor, shape = shape,
                        y = 240 + notes.size * 60
                    )
                    notes.add(note)
                    attach(note)
                } else {
                    val shapeChanged = existing.shape != shape
                    existing.text = text
                    existing.color = color
                    existing.textColor = textColor
                    existing.shape = shape
                    if (shapeChanged) {
                        // 레이아웃 자체가 달라지므로 위치만 남기고 뷰를 새로 만든다
                        views.remove(existing.id)?.let { runCatching { windowManager.removeView(it) } }
                        layoutParams.remove(existing.id)
                        attach(existing)
                    } else {
                        refresh(existing)
                    }
                }
                NoteStore.save(this, notes)
            }
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------- 메모지 부착

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun attach(note: Note) {
        if (views.containsKey(note.id)) {
            refresh(note)
            return
        }

        val layoutRes =
            if (note.shape == Note.SHAPE_DROP) R.layout.view_floating_drop
            else R.layout.view_floating_paper
        val view = LayoutInflater.from(this).inflate(layoutRes, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = note.x
            y = note.y
        }

        // 닫기 버튼은 자식 뷰라 부모의 터치 리스너보다 먼저 이벤트를 받는다.
        view.findViewById<View>(R.id.closeButton).setOnClickListener { remove(note) }

        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var dragging = false
        var scaling = false

        // 두 손가락으로 벌리거나 오므려 크기를 바꾼다
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    note.scale = (note.scale * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                    applySize(note, view, params)
                    runCatching { windowManager.updateViewLayout(view, params) }
                    return true
                }

                override fun onScaleEnd(detector: ScaleGestureDetector) {
                    NoteStore.save(this@FloatingNoteService, notes)
                }
            }
        )

        view.setOnTouchListener { v, event ->
            scaleDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    dragging = false
                    scaling = false
                    v.alpha = baseAlpha * 0.9f
                    true
                }

                // 손가락이 하나 더 닿으면 이동이 아니라 크기 조절이다
                MotionEvent.ACTION_POINTER_DOWN -> {
                    scaling = true
                    dragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (scaling || scaleDetector.isInProgress || event.pointerCount > 1) {
                        return@setOnTouchListener true
                    }
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) dragging = true
                    if (dragging) {
                        params.x = startX + dx
                        params.y = startY + dy
                        runCatching { windowManager.updateViewLayout(v, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = baseAlpha
                    if (scaling) {
                        clampIntoScreen(params, v)
                        runCatching { windowManager.updateViewLayout(v, params) }
                        note.x = params.x
                        note.y = params.y
                        NoteStore.save(this, notes)
                    } else if (dragging) {
                        clampIntoScreen(params, v)
                        runCatching { windowManager.updateViewLayout(v, params) }
                        note.x = params.x
                        note.y = params.y
                        NoteStore.save(this, notes)
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        openEditor(note)
                    }
                    true
                }

                else -> false
            }
        }

        applySize(note, view, params)
        runCatching { windowManager.addView(view, params) }
        views[note.id] = view
        layoutParams[note.id] = params
        refresh(note)
    }

    /**
     * 배율에 맞춰 창과 내부 요소 크기를 다시 잡는다.
     * 글자 크기는 그대로 두므로, 작아지면 들어가는 줄 수가 줄고 나머지는 줄임표로 처리된다.
     */
    private fun applySize(note: Note, view: View, params: WindowManager.LayoutParams) {
        val density = resources.displayMetrics.density
        val label = view.findViewById<TextView>(R.id.noteText)
        val scale = note.scale.coerceIn(MIN_SCALE, MAX_SCALE)

        if (note.shape == Note.SHAPE_DROP) {
            val side = (180 * density * scale).toInt()
            params.width = side
            params.height = side

            val inner = (110 * density * scale).toInt()
            (label.layoutParams as? FrameLayout.LayoutParams)?.let {
                it.width = inner
                it.height = inner
                label.layoutParams = it
            }
            label.maxLines = linesThatFit(label, inner)
        } else {
            val paper = view.findViewById<View>(R.id.paper)
            val pad = (14 * density * scale).toInt()
            paper.layoutParams = paper.layoutParams.apply {
                width = (168 * density * scale).toInt()
            }
            paper.setPadding(pad, pad, pad, pad)
            paper.minimumHeight = (96 * density * scale).toInt()

            params.width = WindowManager.LayoutParams.WRAP_CONTENT
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            label.maxLines = 12
        }
        view.requestLayout()
    }

    /** 주어진 높이에 몇 줄이 들어가는지. 아직 측정 전이면 글자 크기로 어림한다. */
    private fun linesThatFit(label: TextView, heightPx: Int): Int {
        val lineHeight = if (label.lineHeight > 0) label.lineHeight
        else (label.textSize * 1.35f).toInt()
        return (heightPx / lineHeight.coerceAtLeast(1)).coerceIn(1, 20)
    }

    private fun refresh(note: Note) {
        val view = views[note.id] ?: return
        val label = view.findViewById<TextView>(R.id.noteText)
        label.text = note.text
        label.setTextColor(note.textColor)

        // 종이일 때만 배경색을 칠한다. 물방울은 이미지가 배경이다.
        if (note.shape == Note.SHAPE_PAPER) {
            val paper = view.findViewById<View>(R.id.paper)
            (paper.background.mutate() as? GradientDrawable)?.setColor(note.color)
        }
    }

    /** 메모지가 화면 밖으로 완전히 나가 다시 잡을 수 없게 되는 것을 막는다. */
    private fun clampIntoScreen(params: WindowManager.LayoutParams, view: View) {
        val metrics = resources.displayMetrics
        val minVisible = (48 * metrics.density).toInt()
        val maxX = metrics.widthPixels - minVisible
        val maxY = metrics.heightPixels - minVisible
        params.x = params.x.coerceIn(minVisible - view.width, maxX)
        params.y = params.y.coerceIn(0, maxY)
    }

    // ---------------------------------------------------------------- 제거

    private fun remove(note: Note) {
        views.remove(note.id)?.let { runCatching { windowManager.removeView(it) } }
        layoutParams.remove(note.id)
        notes.removeAll { it.id == note.id }
        NoteStore.save(this, notes)
        if (notes.isEmpty()) stopSelf()
    }

    private fun hideAll() {
        views.values.forEach { runCatching { windowManager.removeView(it) } }
        views.clear()
        layoutParams.clear()
        hidden = true
        updateNotification()
    }

    private fun showAll() {
        hidden = false
        notes.forEach { attach(it) }
        updateNotification()
    }

    private fun closeAll() {
        views.values.forEach { runCatching { windowManager.removeView(it) } }
        views.clear()
        layoutParams.clear()
        notes.clear()
        NoteStore.save(this, notes)
        stopSelf()
    }

    override fun onDestroy() {
        views.values.forEach { runCatching { windowManager.removeView(it) } }
        views.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 편집 / 알림

    private fun openEditor(note: Note) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_ID, note.id)
            putExtra(EXTRA_TEXT, note.text)
            putExtra(EXTRA_COLOR, note.color)
            putExtra(EXTRA_TEXT_COLOR, note.textColor)
            putExtra(EXTRA_SHAPE, note.shape)
        }
        startActivity(intent)
    }

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
    }

    /** 접힘 여부에 따라 버튼 문구가 바뀌므로 알림을 다시 그린다. */
    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val toggle = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingNoteService::class.java).setAction(ACTION_TOGGLE_HIDE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val closeAll = PendingIntent.getService(
            this, 2,
            Intent(this, FloatingNoteService::class.java).setAction(ACTION_CLOSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle(
                getString(
                    if (hidden) R.string.notification_title_hidden
                    else R.string.notification_title
                )
            )
            .setContentText(
                getString(
                    if (hidden) R.string.notification_text_hidden
                    else R.string.notification_text
                )
            )
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(if (hidden) R.string.show_notes else R.string.hide_notes), toggle)
            .addAction(0, getString(R.string.close_all), closeAll)
            .build()
    }
}
