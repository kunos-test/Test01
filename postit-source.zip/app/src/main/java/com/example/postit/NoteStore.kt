package com.example.postit

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    val id: String,
    var text: String,
    /** 종이 모양일 때의 종이 색. 물방울은 이미지라 쓰이지 않는다. */
    var color: Int = DEFAULT_PAPER,
    var textColor: Int = DEFAULT_TEXT,
    var shape: String = SHAPE_PAPER,
    /** 핀치로 조절한 크기 배율. 0.5~1.5 사이. */
    var scale: Float = 1f,
    var x: Int = 60,
    var y: Int = 320
) {
    companion object {
        const val SHAPE_PAPER = "paper"
        const val SHAPE_DROP = "drop"
        const val DEFAULT_PAPER = 0xFFFFE08A.toInt()
        const val DEFAULT_TEXT = 0xFF2A2622.toInt()
    }
}

/** 메모 내용, 모양, 색, 홈화면 위 좌표를 SharedPreferences에 보관한다. */
object NoteStore {

    private const val PREF = "postit_store"
    private const val KEY = "notes"
    private const val KEY_OPACITY = "opacity"

    /** 메모지 불투명도. 20~100 사이 퍼센트로 보관한다. */
    fun loadOpacity(context: Context): Int =
        prefs(context).getInt(KEY_OPACITY, 100).coerceIn(20, 100)

    fun saveOpacity(context: Context, percent: Int) {
        prefs(context).edit().putInt(KEY_OPACITY, percent.coerceIn(20, 100)).apply()
    }

    fun load(context: Context): MutableList<Note> {
        val raw = prefs(context).getString(KEY, null) ?: return mutableListOf()
        val result = mutableListOf<Note>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    Note(
                        id = o.getString("id"),
                        text = o.getString("text"),
                        color = o.optInt("color", Note.DEFAULT_PAPER),
                        // 예전 버전에 저장된 메모는 종이 + 검정 글자로 본다
                        textColor = o.optInt("textColor", Note.DEFAULT_TEXT),
                        shape = o.optString("shape", Note.SHAPE_PAPER),
                        scale = o.optDouble("scale", 1.0).toFloat().coerceIn(0.5f, 1.5f),
                        x = o.getInt("x"),
                        y = o.getInt("y")
                    )
                )
            }
        }
        return result
    }

    fun save(context: Context, notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id)
                put("text", n.text)
                put("color", n.color)
                put("textColor", n.textColor)
                put("shape", n.shape)
                put("scale", n.scale.toDouble())
                put("x", n.x)
                put("y", n.y)
            })
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
