package com.example.postit

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    val id: String,
    var text: String,
    var color: Int,
    var x: Int = 60,
    var y: Int = 320
)

/** 메모 내용과 홈화면 위 좌표를 SharedPreferences에 보관한다. */
object NoteStore {

    private const val PREF = "postit_store"
    private const val KEY = "notes"
    private const val KEY_OPACITY = "opacity"

    /** 메모지 불투명도. 20~100 사이 퍼센트로 보관한다. */
    fun loadOpacity(context: Context): Int =
        prefs(context).getInt(KEY_OPACITY, 100).coerceIn(20, 100)

    fun saveOpacity(context: Context, percent: Int) {
        prefs(context).edit().putInt(KEY_OPACITY, percent.coerceIn(20, 100)).apply()
    }

    fun load(context: Context): MutableList<Note> {
        val raw = prefs(context).getString(KEY, null) ?: return mutableListOf()
        val result = mutableListOf<Note>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    Note(
                        id = o.getString("id"),
                        text = o.getString("text"),
                        color = o.getInt("color"),
                        x = o.getInt("x"),
                        y = o.getInt("y")
                    )
                )
            }
        }
        return result
    }

    fun save(context: Context, notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id)
                put("text", n.text)
                put("color", n.color)
                put("x", n.x)
                put("y", n.y)
            })
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
