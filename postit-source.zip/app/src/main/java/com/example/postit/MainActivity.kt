package com.example.postit

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val paperColors = intArrayOf(
        0xFFFFE08A.toInt(), // 노랑
        0xFFFFC3C8.toInt(), // 분홍
        0xFFB6E5C8.toInt(), // 민트
        0xFFBFD9F2.toInt()  // 하늘
    )

    private lateinit var input: EditText
    private lateinit var chips: List<View>
    private lateinit var opacityPreview: View
    private lateinit var opacityValue: TextView
    private var opacityPercent = 100
    private var selectedColor = 0xFFFFE08A.toInt()
    private var editingId: String? = null

    private val overlayPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (canOverlay()) stickNote()
            else toast(getString(R.string.need_overlay_permission))
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        chips = listOf(
            findViewById(R.id.chip0),
            findViewById(R.id.chip1),
            findViewById(R.id.chip2),
            findViewById(R.id.chip3)
        )

        chips.forEachIndexed { index, chip ->
            (chip.background.mutate() as? GradientDrawable)?.setColor(paperColors[index])
            chip.setOnClickListener { selectColor(index) }
        }
        selectColor(0)
        setUpOpacity()

        findViewById<Button>(R.id.stickButton).setOnClickListener {
            if (canOverlay()) stickNote() else requestOverlay()
        }
        findViewById<TextView>(R.id.closeAllButton).setOnClickListener {
            startService(
                Intent(this, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_CLOSE_ALL)
            )
            toast(getString(R.string.all_closed))
        }

        askNotificationPermission()
        applyEditIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyEditIntent(intent)
    }

    /** 떠 있는 메모지를 탭하면 그 메모를 여기서 이어서 고친다. */
    private fun applyEditIntent(intent: Intent?) {
        val id = intent?.getStringExtra(FloatingNoteService.EXTRA_ID) ?: return
        editingId = id
        input.setText(intent.getStringExtra(FloatingNoteService.EXTRA_TEXT).orEmpty())
        input.setSelection(input.text.length)
        val color = intent.getIntExtra(FloatingNoteService.EXTRA_COLOR, paperColors[0])
        val index = paperColors.indexOf(color)
        selectColor(if (index >= 0) index else 0)
        findViewById<Button>(R.id.stickButton).setText(R.string.update_note)
    }

    private fun selectColor(index: Int) {
        selectedColor = paperColors[index]
        if (::opacityPreview.isInitialized) {
            (opacityPreview.background.mutate() as? GradientDrawable)?.setColor(selectedColor)
        }
        chips.forEachIndexed { i, chip ->
            chip.scaleX = if (i == index) 1.15f else 1f
            chip.scaleY = if (i == index) 1.15f else 1f
            chip.alpha = if (i == index) 1f else 0.45f
        }
    }

    private fun setUpOpacity() {
        opacityPreview = findViewById(R.id.opacityPreview)
        opacityValue = findViewById(R.id.opacityValue)
        val seek = findViewById<SeekBar>(R.id.opacitySeek)

        opacityPercent = NoteStore.loadOpacity(this)
        seek.progress = opacityPercent
        applyOpacity(opacityPercent, push = false)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                applyOpacity(value, push = false)
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}

            // 손을 뗐을 때만 저장하고 떠 있는 메모에 반영한다
            override fun onStopTrackingTouch(bar: SeekBar) {
                applyOpacity(bar.progress, push = true)
            }
        })
    }

    private fun applyOpacity(percent: Int, push: Boolean) {
        opacityPercent = percent.coerceIn(20, 100)
        opacityValue.text = getString(R.string.percent_format, opacityPercent)
        opacityPreview.alpha = opacityPercent / 100f
        (opacityPreview.background.mutate() as? GradientDrawable)?.setColor(selectedColor)

        if (!push) return
        NoteStore.saveOpacity(this, opacityPercent)

        // 떠 있는 메모가 없는데 서비스를 깨우지는 않는다
        if (NoteStore.load(this).isEmpty()) return
        startService(
            Intent(this, FloatingNoteService::class.java)
                .setAction(FloatingNoteService.ACTION_SET_OPACITY)
                .putExtra(FloatingNoteService.EXTRA_OPACITY, opacityPercent)
        )
    }

    private fun stickNote() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) {
            toast(getString(R.string.empty_note))
            return
        }

        val intent = Intent(this, FloatingNoteService::class.java).apply {
            action = FloatingNoteService.ACTION_SHOW
            putExtra(FloatingNoteService.EXTRA_ID, editingId ?: System.currentTimeMillis().toString())
            putExtra(FloatingNoteService.EXTRA_TEXT, text)
            putExtra(FloatingNoteService.EXTRA_COLOR, selectedColor)
        }
        ContextCompat.startForegroundService(this, intent)

        input.setText("")
        editingId = null
        findViewById<Button>(R.id.stickButton).setText(R.string.stick_note)
        moveTaskToBack(true) // 바로 홈화면에서 결과를 보게 한다
    }

    private fun canOverlay() = Settings.canDrawOverlays(this)

    private fun requestOverlay() {
        toast(getString(R.string.grant_overlay_hint))
        overlayPermission.launch(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
