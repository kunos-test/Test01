package com.example.postit

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private companion object {
        const val TEXT_BLACK = 0xFF2A2622.toInt()
        const val TEXT_WHITE = 0xFFFFFFFF.toInt()
    }

    private val paperColors = intArrayOf(
        0xFFFFE08A.toInt(), // 노랑
        0xFFFFC3C8.toInt(), // 분홍
        0xFFB6E5C8.toInt(), // 민트
        0xFFBFD9F2.toInt()  // 하늘
    )

    private lateinit var input: EditText
    private lateinit var shapePaper: View
    private lateinit var shapeDrop: View
    private lateinit var paperColorSection: View
    private lateinit var chips: List<View>
    private lateinit var swatchBlack: View
    private lateinit var swatchWhite: View
    private lateinit var opacityPreview: View
    private lateinit var opacityValue: TextView

    private var selectedShape = Note.SHAPE_PAPER
    private var selectedPaperColor = paperColors[0]
    private var selectedTextColor = TEXT_BLACK
    private var opacityPercent = 100
    private var editingId: String? = null

    private val overlayPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (canOverlay()) stickNote()
            else toast(getString(R.string.need_overlay_permission))
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        setUpShape()
        setUpPaperColor()
        setUpTextColor()
        setUpOpacity()

        findViewById<Button>(R.id.stickButton).setOnClickListener {
            if (canOverlay()) stickNote() else requestOverlay()
        }
        findViewById<TextView>(R.id.closeAllButton).setOnClickListener {
            startService(
                Intent(this, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_CLOSE_ALL)
            )
            toast(getString(R.string.all_closed))
        }

        askNotificationPermission()
        applyEditIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyEditIntent(intent)
    }

    /** 떠 있는 메모지를 탭하면 그 메모의 설정을 그대로 불러와 이어서 고친다. */
    private fun applyEditIntent(intent: Intent?) {
        val id = intent?.getStringExtra(FloatingNoteService.EXTRA_ID) ?: return
        editingId = id
        input.setText(intent.getStringExtra(FloatingNoteService.EXTRA_TEXT).orEmpty())
        input.setSelection(input.text.length)

        selectShape(intent.getStringExtra(FloatingNoteService.EXTRA_SHAPE) ?: Note.SHAPE_PAPER)
        val paper = intent.getIntExtra(FloatingNoteService.EXTRA_COLOR, paperColors[0])
        selectPaperColor(paperColors.indexOf(paper).takeIf { it >= 0 } ?: 0)
        selectTextColor(intent.getIntExtra(FloatingNoteService.EXTRA_TEXT_COLOR, TEXT_BLACK))

        findViewById<Button>(R.id.stickButton).setText(R.string.update_note)
    }

    // ---------------------------------------------------------------- 모양

    private fun setUpShape() {
        shapePaper = findViewById(R.id.shapePaper)
        shapeDrop = findViewById(R.id.shapeDrop)
        paperColorSection = findViewById(R.id.paperColorSection)
        shapePaper.setOnClickListener { selectShape(Note.SHAPE_PAPER) }
        shapeDrop.setOnClickListener { selectShape(Note.SHAPE_DROP) }
        selectShape(selectedShape)
    }

    private fun selectShape(shape: String) {
        selectedShape = if (shape == Note.SHAPE_DROP) Note.SHAPE_DROP else Note.SHAPE_PAPER
        val paperPicked = selectedShape == Note.SHAPE_PAPER

        shapePaper.alpha = if (paperPicked) 1f else 0.4f
        shapeDrop.alpha = if (paperPicked) 0.4f else 1f

        // 물방울은 이미지가 고정이라 종이 색을 고를 이유가 없다
        paperColorSection.visibility = if (paperPicked) View.VISIBLE else View.GONE
        refreshPreview()
    }

    // ---------------------------------------------------------------- 종이 색

    private fun setUpPaperColor() {
        chips = listOf(
            findViewById(R.id.chip0),
            findViewById(R.id.chip1),
            findViewById(R.id.chip2),
            findViewById(R.id.chip3)
        )
        chips.forEachIndexed { index, chip ->
            (chip.background.mutate() as? GradientDrawable)?.setColor(paperColors[index])
            chip.setOnClickListener { selectPaperColor(index) }
        }
        selectPaperColor(0)
    }

    private fun selectPaperColor(index: Int) {
        selectedPaperColor = paperColors[index]
        chips.forEachIndexed { i, chip ->
            val picked = i == index
            chip.scaleX = if (picked) 1.15f else 1f
            chip.scaleY = if (picked) 1.15f else 1f
            chip.alpha = if (picked) 1f else 0.45f
        }
        refreshPreview()
    }

    // ---------------------------------------------------------------- 글자 색

    private fun setUpTextColor() {
        swatchBlack = findViewById(R.id.swatchBlack)
        swatchWhite = findViewById(R.id.swatchWhite)
        swatchBlack.setOnClickListener { selectTextColor(TEXT_BLACK) }
        swatchWhite.setOnClickListener { selectTextColor(TEXT_WHITE) }
        selectTextColor(selectedTextColor)
    }

    private fun selectTextColor(color: Int) {
        selectedTextColor = if (color == TEXT_WHITE) TEXT_WHITE else TEXT_BLACK
        val blackPicked = selectedTextColor == TEXT_BLACK

        swatchBlack.scaleX = if (blackPicked) 1.15f else 1f
        swatchBlack.scaleY = if (blackPicked) 1.15f else 1f
        swatchBlack.alpha = if (blackPicked) 1f else 0.4f
        swatchWhite.scaleX = if (blackPicked) 1f else 1.15f
        swatchWhite.scaleY = if (blackPicked) 1f else 1.15f
        swatchWhite.alpha = if (blackPicked) 0.4f else 1f
    }

    // ---------------------------------------------------------------- 투명도

    private fun setUpOpacity() {
        opacityPreview = findViewById(R.id.opacityPreview)
        opacityValue = findViewById(R.id.opacityValue)
        val seek = findViewById<SeekBar>(R.id.opacitySeek)

        opacityPercent = NoteStore.loadOpacity(this)
        seek.progress = opacityPercent
        applyOpacity(opacityPercent, push = false)
        refreshPreview()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                applyOpacity(value, push = false)
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}

            // 손을 뗐을 때만 저장하고 떠 있는 메모에 반영한다
            override fun onStopTrackingTouch(bar: SeekBar) {
                applyOpacity(bar.progress, push = true)
            }
        })
    }

    private fun applyOpacity(percent: Int, push: Boolean) {
        opacityPercent = percent.coerceIn(20, 100)
        opacityValue.text = getString(R.string.percent_format, opacityPercent)
        opacityPreview.alpha = opacityPercent / 100f

        if (!push) return
        NoteStore.saveOpacity(this, opacityPercent)

        // 떠 있는 메모가 없는데 서비스를 깨우지는 않는다
        if (NoteStore.load(this).isEmpty()) return
        startService(
            Intent(this, FloatingNoteService::class.java)
                .setAction(FloatingNoteService.ACTION_SET_OPACITY)
                .putExtra(FloatingNoteService.EXTRA_OPACITY, opacityPercent)
        )
    }

    /** 미리보기를 지금 고른 모양과 색으로 맞춘다. */
    private fun refreshPreview() {
        if (!::opacityPreview.isInitialized) return
        if (selectedShape == Note.SHAPE_DROP) {
            opacityPreview.setBackgroundResource(R.drawable.note_paper)
        } else {
            opacityPreview.setBackgroundResource(R.drawable.bg_chip)
            (opacityPreview.background.mutate() as? GradientDrawable)?.setColor(selectedPaperColor)
        }
    }

    // ---------------------------------------------------------------- 붙이기

    private fun stickNote() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) {
            toast(getString(R.string.empty_note))
            return
        }

        val intent = Intent(this, FloatingNoteService::class.java).apply {
            action = FloatingNoteService.ACTION_SHOW
            putExtra(FloatingNoteService.EXTRA_ID, editingId ?: System.currentTimeMillis().toString())
            putExtra(FloatingNoteService.EXTRA_TEXT, text)
            putExtra(FloatingNoteService.EXTRA_COLOR, selectedPaperColor)
            putExtra(FloatingNoteService.EXTRA_TEXT_COLOR, selectedTextColor)
            putExtra(FloatingNoteService.EXTRA_SHAPE, selectedShape)
        }
        ContextCompat.startForegroundService(this, intent)

        input.setText("")
        editingId = null
        findViewById<Button>(R.id.stickButton).setText(R.string.stick_note)
        moveTaskToBack(true) // 바로 홈화면에서 결과를 보게 한다
    }

    // ---------------------------------------------------------------- 권한

    private fun canOverlay() = Settings.canDrawOverlays(this)

    private fun requestOverlay() {
        toast(getString(R.string.grant_overlay_hint))
        overlayPermission.launch(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
